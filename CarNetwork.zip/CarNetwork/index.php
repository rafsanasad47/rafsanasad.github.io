
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Car Network</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
		
		<!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/half-slider.css" rel="stylesheet">

		
		<style></style>
	</head>
<body>

		
		<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="index.php" class="navbar-brand">Car Network</a>
			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Home</a></li>
				<li><a href="t.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
				<li><a href="ab.php"><span class="glyphicon glyphicon-modal-window"></span>About Us</a></li>
			</ul>
			
			
		</div>
	</div>
</div>	
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
		
		
	<section class="slider_area"> 
		
		<div id="myCarousel" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner">
    <div class="item active">
      <img src="product_images/la.jpg" alt="Los Angeles">
    </div>

    <div class="item">
      <img src="product_images/chicago.jpg" alt="Chicago">
    </div>

    <div class="item">
      <img src="product_images/ny.jpg" alt="New York">
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
		</section>
		
		
		
		<section class="kcorner_area"> 
			<div class="container kcorner"> 
				<div class="row"> 
					<div class="col-md-12"> 
						<div class="ktext"> 
						<h1>Welcome to Car Network</h1>
						<p>Car Network is one of the best Carshop in the town .As car’s are very much necessary for present world and for communication we believe that our shop will give the customer proper service and also best satisfaction.</p>


					</div>
					</div>
				
				</div>
			</div>
		
		
		
		
		</section>
		
		
		<footer class="footer_area"> 
			<div class="container footer"> 
				<div class="row"> 
					<div class="col-md-12"> 
					<div class="copy"> 
					<p>&copy; CAR NETWORK, ALL RIGHTS RESERVED 2018 </p>
					</div>
					</div>
				
			
			
			
			
			</div>
		
	
		</footer>
		
		
		

</body>
</html>
















































